#include <iostream>
#include <vector>
using namespace std;

class csito
{
private:
vector<bool> tab;
public:
     csito();             //konstruktor
    ~csito();            //destuktor
    void odsiej(int a);  //eliminuje liczby zlozone
    void wyswietl(int a);//wyswietla liczby pierwsze
    void sprawdz(int x); //sprawdza podana liczbe
};
csito::csito()
{
    cout<<"Uzyto konstruktora\n";
    for(int i=0; i<1; i++)
    {
        tab.push_back(false);
    }
}
csito::~csito()
{
    cout<<"Uzyto destruktora";
    tab.clear();
}
void csito::odsiej(int a)
{
	for(int i=0; i<a; i++)
		tab.push_back(true);

    for (int i=2; i*i<a; i++)
    {
        for (int j=i*i ; j<a; j=j+i)
            tab.push_back(false);
    }
}
void csito::wyswietl(int a)
{
   cout<<"Liczby pierwsze: ";
   for(int i=2;i<a;i++)
    {
		if(tab[i]==true)
			cout<<i<<",";
    }
    cout<<endl;
}
void csito::sprawdz(int x)
{
   if(tab[x]==true) cout<<"Liczba "<<x<<" jest pierwsza\n";
   else cout<<"Liczba "<<x<<" nie jest pierwsza\n";
}
int main()
{
    int x,y;
    csito nr1;

    cout<<"Podaj zakres gorny: ";
    cin>>x;
    nr1.odsiej(x);
    nr1.wyswietl(x);
    cout<<"Podaj ktora liczbe sprawdzic: ";
    cin>>y;
    nr1.sprawdz(y);
    return 0;
}
